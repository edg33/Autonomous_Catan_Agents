import datetime
import numpy as np
import random
from math import log, sqrt 
import copy
import pprint
import itertools
import matplotlib.pyplot as plt

These are the necessary dependencies for our program. To run, import these above and run all cells from the top. To change the number of max_moves or time constraints, adjust the values within the init of the Monte Carlo Tree Search class. This program was designed in python3 and requires jupyter notebook to run.